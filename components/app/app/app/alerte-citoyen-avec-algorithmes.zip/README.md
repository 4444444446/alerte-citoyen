# ALERTE CITOYEN — VERSION PRODUCTION

**© Coulibaly Zie Aboudramane — Tous droits réservés.**

## Architecture
Next.js + TypeScript + PostgreSQL + Prisma. Le projet est conçu pour être déployé comme Web Service sur Render, avec Render Postgres.

## Lancer localement
1. Installer Node.js.
2. `npm install`
3. Copier `.env.example` vers `.env` et renseigner DATABASE_URL.
4. `npx prisma db push`
5. `npm run dev`

## Render
Le fichier `render.yaml` décrit le Web Service et PostgreSQL. Pour une application dynamique Next.js, Render recommande un Web Service ; un Static Site ne convient pas aux API/SSR. Voir la documentation Render.

Build: `npm ci && npx prisma generate && npm run build`
Start: `npm start`

## Comptes
- `/register`
- `/login`
- `/dashboard`

## Données
Les comptes, alertes, contributions, récompenses et journaux sont stockés dans PostgreSQL.

## IMPORTANT — mise en production
Cette version fournit l'architecture complète du socle mais certaines briques doivent être finalisées avant ouverture mondiale : vérification email, reset password, 2FA, stockage objet privé pour photos, antivirus sur uploads, modération avancée, rate limiting distribué, observabilité, sauvegardes/restore testés, gestion des demandes de droits, procédure d'incident, fournisseur de paiement agréé et conformité juridique.

## Politique ivoirienne
La page `/privacy` contient une politique adaptée comme base au contexte ivoirien. Elle doit être revue par un juriste et les formalités auprès de l'autorité compétente doivent être vérifiées avant traitement réel de données personnelles.

## Sécurité
Ne jamais committer `.env`, secrets, mots de passe ou clés API dans Git.

## Algorithmes ajoutés
- **`lib/matching.ts`** — rapprochement automatique entre alertes "personne disparue" : similarité de nom (distance de Levenshtein), proximité géographique (formule de Haversine), proximité de date. Score composite pondéré (nom 50%, lieu 30%, date 20%). Exposé via `GET /api/alerts/:id/matches` (réservé MODERATOR/ADMIN). Les suggestions sont stockées dans le modèle `MatchSuggestion` et doivent être validées par un humain — rien n'est automatique.
- **`lib/search.ts`** — recherche textuelle (Prisma `contains`) + classement par pertinence (titre/description/urgence/fraîcheur/engagement). Exposé via `GET /api/alerts?q=&type=&city=&page=`.
- **`lib/rateLimit.ts`** — limitation de débit par fenêtre glissante (login, inscription, création d'alerte, contributions). Limite connue : compteur en mémoire, à migrer vers Redis en cas de scaling multi-instance.
- **`lib/points.ts`** — barème de points communautaires + score de confiance anti-fraude sur les contributions (âge du compte, répétition, longueur du message) pour prioriser la file de modération.
- Nouvelles routes : `POST /api/alerts/:id/moderate` (approuver/rejeter — sans elle aucune alerte PENDING ne devenait ACTIVE), `POST /api/alerts/:id/contributions`.
- Schéma Prisma : ajout de `lat/lng`, `personName/personAge/personSex/distinguishingMarks` sur `Alert`, nouveau modèle `MatchSuggestion`.

Après avoir récupéré ce zip : `npx prisma db push` (ou `migrate dev`) pour appliquer les nouveaux champs avant de relancer l'app.
