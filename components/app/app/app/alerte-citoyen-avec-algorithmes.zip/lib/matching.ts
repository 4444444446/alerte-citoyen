// lib/matching.ts
// Algorithmes de rapprochement automatique entre alertes.
//
// Objectif : quand une alerte "personne disparue" est créée, on calcule un
// score de similarité avec les alertes existantes (ex. avis de recherche,
// signalements) pour suggérer aux modérateurs des correspondances possibles.
// Rien n'est jamais publié/confirmé automatiquement : ce sont des SUGGESTIONS
// qu'un modérateur humain doit valider (voir app/api/alerts/[id]/matches).

export type MatchableAlert = {
  id: string;
  type: string;
  personName: string | null;
  personAge: number | null;
  personSex: string | null;
  city: string | null;
  region: string | null;
  lat: number | null;
  lng: number | null;
  dateOccurred: Date | null;
  description: string;
};

/**
 * Distance de Levenshtein (nombre minimal d'opérations d'édition
 * — insertion, suppression, substitution — pour passer de a à b).
 * Utilisée pour tolérer les fautes de frappe/orthographe dans les noms
 * (ex. "Kouadio" vs "Kouassio").
 */
export function levenshtein(a: string, b: string): number {
  const s = a.toLowerCase().trim();
  const t = b.toLowerCase().trim();
  const m = s.length, n = t.length;
  if (m === 0) return n;
  if (n === 0) return m;

  let prev = new Array(n + 1);
  let curr = new Array(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;

  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    for (let j = 1; j <= n; j++) {
      const cost = s[i - 1] === t[j - 1] ? 0 : 1;
      curr[j] = Math.min(
        prev[j] + 1,      // suppression
        curr[j - 1] + 1,  // insertion
        prev[j - 1] + cost // substitution
      );
    }
    [prev, curr] = [curr, prev];
  }
  return prev[n];
}

/** Similarité normalisée entre 0 (rien en commun) et 1 (identique). */
export function nameSimilarity(a?: string | null, b?: string | null): number {
  if (!a || !b) return 0;
  const dist = levenshtein(a, b);
  const maxLen = Math.max(a.trim().length, b.trim().length, 1);
  return Math.max(0, 1 - dist / maxLen);
}

/**
 * Distance du grand cercle (formule de Haversine) entre deux points
 * GPS, en kilomètres. Sert à estimer la proximité géographique entre
 * le lieu de disparition et le lieu où une personne a été retrouvée/vue.
 */
export function haversineKm(
  lat1: number, lng1: number, lat2: number, lng2: number
): number {
  const R = 6371; // rayon moyen de la Terre en km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const rLat1 = (lat1 * Math.PI) / 180;
  const rLat2 = (lat2 * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rLat1) * Math.cos(rLat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Score de proximité géographique : 1 = même endroit, décroît avec la distance. */
function distanceScore(distanceKm: number | null): number {
  if (distanceKm === null) return 0.5; // pas d'info -> score neutre
  if (distanceKm <= 5) return 1;
  if (distanceKm >= 300) return 0;
  return 1 - distanceKm / 300; // décroissance linéaire jusqu'à 300 km
}

/** Score de proximité temporelle : plus l'écart de dates est faible, mieux c'est. */
function dateScore(deltaDays: number | null): number {
  if (deltaDays === null) return 0.5;
  const abs = Math.abs(deltaDays);
  if (abs <= 2) return 1;
  if (abs >= 60) return 0;
  return 1 - abs / 60;
}

/** Correspondance approximative de ville/région quand les coordonnées manquent. */
function locationTextScore(a: MatchableAlert, b: MatchableAlert): number {
  const norm = (s: string | null) => (s || "").trim().toLowerCase();
  if (!norm(a.city) && !norm(b.city)) return 0.5;
  if (norm(a.city) && norm(a.city) === norm(b.city)) return 1;
  if (norm(a.region) && norm(a.region) === norm(b.region)) return 0.6;
  return 0.1;
}

export type MatchResult = {
  targetId: string;
  score: number;        // score composite 0..1
  nameScore: number;
  distanceKm: number | null;
  dateDeltaDays: number | null;
};

/**
 * Score composite de rapprochement entre deux alertes (0 à 1).
 * Pondération : nom (50%), localisation (30%), date (20%).
 * Le nom pèse le plus car c'est le signal le plus fiable ; la
 * localisation/date affinent en cas d'homonymie.
 */
export function computeMatchScore(a: MatchableAlert, b: MatchableAlert): MatchResult {
  const nScore = nameSimilarity(a.personName, b.personName);

  let distanceKm: number | null = null;
  let locScore: number;
  if (a.lat != null && a.lng != null && b.lat != null && b.lng != null) {
    distanceKm = haversineKm(a.lat, a.lng, b.lat, b.lng);
    locScore = distanceScore(distanceKm);
  } else {
    locScore = locationTextScore(a, b);
  }

  let dateDeltaDays: number | null = null;
  if (a.dateOccurred && b.dateOccurred) {
    dateDeltaDays = Math.round(
      (a.dateOccurred.getTime() - b.dateOccurred.getTime()) / 86400000
    );
  }
  const dScore = dateScore(dateDeltaDays);

  // Bonus léger si l'âge déclaré est très proche (tolérance de 2 ans,
  // utile car l'âge est souvent estimé).
  let ageBonus = 0;
  if (a.personAge != null && b.personAge != null) {
    ageBonus = Math.abs(a.personAge - b.personAge) <= 2 ? 0.05 : 0;
  }

  const composite = nScore * 0.5 + locScore * 0.3 + dScore * 0.2 + ageBonus;

  return {
    targetId: b.id,
    score: Math.min(1, Math.round(composite * 1000) / 1000),
    nameScore: Math.round(nScore * 1000) / 1000,
    distanceKm: distanceKm !== null ? Math.round(distanceKm * 10) / 10 : null,
    dateDeltaDays,
  };
}

/** Seuil sous lequel une suggestion n'est même pas proposée (bruit). */
export const MATCH_MIN_SCORE = 0.35;

/**
 * Classe une liste de candidats par pertinence décroissante et ne garde
 * que ceux qui dépassent le seuil minimal.
 */
export function rankMatches(
  source: MatchableAlert,
  candidates: MatchableAlert[]
): MatchResult[] {
  return candidates
    .filter((c) => c.id !== source.id)
    .map((c) => computeMatchScore(source, c))
    .filter((r) => r.score >= MATCH_MIN_SCORE)
    .sort((x, y) => y.score - x.score);
}
