// lib/points.ts
// Algorithme de calcul des points communautaires et de détection
// de fraude simple sur les contributions/récompenses.

export const POINTS = {
  CONTRIBUTION_SUBMITTED: 2,   // dépôt d'une contribution (avant vérification)
  CONTRIBUTION_VERIFIED: 15,   // un modérateur confirme l'info comme utile
  ALERT_RESOLVED_AUTHOR: 25,   // l'auteur d'une alerte qui se résout
  ALERT_RESOLVED_HELPER: 50,   // la contribution a directement mené à la résolution
} as const;

/**
 * Score de confiance anti-fraude simple pour une contribution, avant
 * validation humaine. Ne bloque rien automatiquement : sert à trier la
 * file de modération (les scores bas passent en priorité de vérif).
 *
 * Facteurs pénalisants :
 *  - compte très récent (< 24h)
 *  - beaucoup de contributions déjà envoyées sur la même alerte par le même auteur
 *  - message très court (peu informatif)
 */
export function contributionTrustScore(input: {
  accountAgeHours: number;
  priorContributionsOnAlert: number;
  messageLength: number;
}): number {
  let score = 1;
  if (input.accountAgeHours < 24) score -= 0.4;
  else if (input.accountAgeHours < 24 * 7) score -= 0.15;

  if (input.priorContributionsOnAlert >= 3) score -= 0.3;

  if (input.messageLength < 20) score -= 0.2;

  return Math.max(0, Math.min(1, Math.round(score * 100) / 100));
}

/**
 * Calcule le nombre de points à créditer pour un événement donné.
 * Centralisé ici pour que toute la logique de gamification soit
 * auditable à un seul endroit (les routes API ne font qu'appeler ceci).
 */
export function pointsForEvent(
  event: keyof typeof POINTS
): number {
  return POINTS[event];
}
