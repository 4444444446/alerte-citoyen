// lib/rateLimit.ts
// Algorithme "sliding window" (fenêtre glissante) pour limiter le nombre
// de requêtes par identifiant (IP ou utilisateur) sur une fenêtre de temps.
//
// LIMITE CONNUE : ce compteur vit en mémoire du process Node. Sur Render
// avec plusieurs instances (scaling horizontal), chaque instance a son
// propre compteur. C'est suffisant pour une seule instance (cas actuel du
// render.yaml) ; pour du multi-instance il faudra migrer vers Redis (ex.
// Upstash) — le README mentionne déjà "rate limiting distribué" comme
// chantier restant.

type Bucket = { timestamps: number[] };
const buckets = new Map<string, Bucket>();

// Purge périodique pour éviter une fuite mémoire sur un process long-lived.
const MAX_BUCKETS = 50_000;

export type RateLimitResult = {
  allowed: boolean;
  remaining: number;
  retryAfterMs: number;
};

/**
 * @param key identifiant unique (ex. `login:${ip}`, `alert-create:${userId}`)
 * @param limit nombre maximal de requêtes autorisées dans la fenêtre
 * @param windowMs durée de la fenêtre glissante en millisecondes
 */
export function rateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  const now = Date.now();

  if (buckets.size > MAX_BUCKETS) buckets.clear(); // garde-fou mémoire simple

  const bucket = buckets.get(key) ?? { timestamps: [] };
  // On ne garde que les requêtes tombées dans la fenêtre glissante.
  bucket.timestamps = bucket.timestamps.filter((t) => now - t < windowMs);

  if (bucket.timestamps.length >= limit) {
    const oldest = bucket.timestamps[0];
    buckets.set(key, bucket);
    return {
      allowed: false,
      remaining: 0,
      retryAfterMs: windowMs - (now - oldest),
    };
  }

  bucket.timestamps.push(now);
  buckets.set(key, bucket);
  return {
    allowed: true,
    remaining: limit - bucket.timestamps.length,
    retryAfterMs: 0,
  };
}

/** Extrait une IP raisonnable des en-têtes standards derrière un proxy (Render). */
export function clientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return req.headers.get("x-real-ip") || "unknown";
}

/** Préréglages utilisés par les routes sensibles de l'application. */
export const RATE_LIMITS = {
  login: { limit: 8, windowMs: 10 * 60 * 1000 },       // 8 tentatives / 10 min
  register: { limit: 5, windowMs: 60 * 60 * 1000 },    // 5 inscriptions / h
  alertCreate: { limit: 10, windowMs: 60 * 60 * 1000 }, // 10 alertes / h
  contribution: { limit: 20, windowMs: 60 * 60 * 1000 },
} as const;
