import {NextResponse} from "next/server";
import {db} from "@/lib/db";
import {getCurrentUser} from "@/lib/auth";
import {rankMatches} from "@/lib/matching";

// GET /api/alerts/:id/matches
// Calcule les suggestions de rapprochement (nom + lieu + date) entre cette
// alerte et les autres alertes actives du même type de dossier. Réservé aux
// modérateurs/admins : ce sont des pistes à vérifier humainement, jamais des
// confirmations automatiques.
export async function GET(req: Request, {params}: {params: Promise<{id: string}>}) {
  const u = await getCurrentUser();
  if (!u || (u.role !== "MODERATOR" && u.role !== "ADMIN")) {
    return NextResponse.json({error: "Accès réservé à la modération."}, {status: 403});
  }

  const {id} = await params;
  const source = await db.alert.findUnique({where: {id}});
  if (!source) return NextResponse.json({error: "Alerte introuvable."}, {status: 404});

  // On ne rapproche que les personnes disparues avec des avis de recherche/
  // signalements potentiellement liés, dans une fenêtre de temps raisonnable.
  const candidates = await db.alert.findMany({
    where: {
      id: {not: id},
      type: "MISSING_PERSON",
      status: {in: ["ACTIVE", "PENDING"]},
      personName: {not: null},
    },
    take: 500,
  });

  const results = rankMatches(source, candidates);

  // Persiste les meilleures suggestions pour ne pas recalculer à chaque
  // consultation et garder un historique consultable par la modération.
  for (const r of results.slice(0, 20)) {
    await db.matchSuggestion.upsert({
      where: {sourceAlertId_targetAlertId: {sourceAlertId: id, targetAlertId: r.targetId}},
      update: {score: r.score, nameScore: r.nameScore, distanceKm: r.distanceKm, dateDeltaDays: r.dateDeltaDays},
      create: {
        sourceAlertId: id,
        targetAlertId: r.targetId,
        score: r.score,
        nameScore: r.nameScore,
        distanceKm: r.distanceKm,
        dateDeltaDays: r.dateDeltaDays,
      },
    });
  }

  const candidateMap = new Map(candidates.map((c) => [c.id, c]));
  return NextResponse.json({
    ok: true,
    matches: results.slice(0, 20).map((r) => ({
      ...r,
      alert: candidateMap.has(r.targetId)
        ? {
            id: r.targetId,
            title: candidateMap.get(r.targetId)!.title,
            city: candidateMap.get(r.targetId)!.city,
            personName: candidateMap.get(r.targetId)!.personName,
          }
        : null,
    })),
  });
}
